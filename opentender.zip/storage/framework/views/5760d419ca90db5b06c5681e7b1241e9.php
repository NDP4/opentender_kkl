<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="text-xl font-semibold leading-tight text-gray-800">
            Pengumuman
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="mx-auto max-w-7xl sm:px-6 lg:px-8">
            <?php if(session('success')): ?>
                <div class="p-4 mb-4 text-green-700 bg-green-100 border border-green-400 rounded">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <div class="overflow-hidden bg-white shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <div class="space-y-6">
                        <?php if(isset($announcement)): ?>
                            <?php if($announcement->type === 'winner'): ?>
                                <?php if(in_array(auth()->id(), $announcement->selected_biro_ids)): ?>
                                    <div class="p-6 border border-green-200 rounded-lg bg-green-50">
                                        <h3 class="mb-4 text-lg font-semibold text-gray-800">Selamat! Anda Menjadi Pemenang Tender</h3>
                                        <div class="mb-6 prose max-w-none">
                                            <p>Dengan senang hati kami informasikan bahwa biro perjalanan Anda telah terpilih sebagai pemenang tender KKL D3 TI UDINUS. Keputusan ini diambil setelah melalui proses evaluasi yang menyeluruh terhadap proposal dan presentasi yang telah Anda berikan.</p>
                                            <p class="mt-4"><?php echo e($announcement->content); ?></p>
                                        </div>
                                        <div class="mt-4 text-sm text-gray-600">
                                            <p>Tanggal Pengumuman: <?php echo e($announcement->created_at->format('d M Y H:i')); ?></p>
                                            <p>Tanggal Pelaksanaan: <?php echo e($announcement->announcement_date->format('d M Y H:i')); ?></p>
                                        </div>
                                    </div>
                                <?php elseif(auth()->user()->presentationConfirmations()->where('status', 'confirmed')->exists()): ?>
                                    <div class="p-6 bg-white border border-gray-200 rounded-lg">
                                        <h3 class="mb-4 text-lg font-semibold text-gray-800">Pengumuman Hasil Akhir Tender</h3>
                                        <div class="mb-6 prose max-w-none">
                                            <p>Terima kasih atas partisipasi Anda dalam proses tender KKL D3 TI UDINUS. Setelah melalui proses evaluasi yang menyeluruh, dengan berat hati kami informasikan bahwa biro perjalanan Anda belum terpilih sebagai pemenang tender KKL.</p>
                                            <p class="mt-4">Kami sangat menghargai waktu dan upaya yang telah Anda berikan selama proses tender ini.</p>
                                        </div>
                                        <div class="mt-4 text-sm text-gray-600">
                                            <p>Tanggal Pengumuman: <?php echo e($announcement->created_at->format('d M Y H:i')); ?></p>
                                        </div>
                                    </div>
                                <?php else: ?>
                                    <div class="p-6 bg-white border border-gray-200 rounded-lg">
                                        <h3 class="mb-4 text-lg font-semibold text-gray-800">Pengumuman Pemenang Tender</h3>
                                        <div class="mb-6 prose max-w-none">
                                            <?php
                                                $winnerBiro = \App\Models\User::find($announcement->selected_biro_ids[0])->proposals()->latest()->first();
                                            ?>
                                            <p>Biro terpilih dalam KKL D3 TI UDINUS adalah <?php echo e($winnerBiro->nama_biro); ?>.</p>
                                        </div>
                                        <div class="mt-4 text-sm text-gray-600">
                                            <p>Tanggal Pengumuman: <?php echo e($announcement->created_at->format('d M Y H:i')); ?></p>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            <?php elseif($announcement->type === 'presentation'): ?>
                                <?php if($announcement->isUserSelected(auth()->user())): ?>
                                    <div class="p-6 border border-blue-200 rounded-lg bg-blue-50">
                                        <h3 class="mb-4 text-lg font-semibold text-gray-800"><?php echo e($announcement->title); ?></h3>
                                        <div class="mb-6 prose max-w-none">
                                            <?php echo nl2br(e($announcement->content)); ?>


                                            <?php if($announcement->announcement_date): ?>
                                                <div class="p-4 mt-4 bg-white border border-blue-200 rounded-lg">
                                                    <p class="font-semibold">Jadwal Presentasi:</p>
                                                    <p><?php echo e($announcement->announcement_date->format('l, d M Y H:i')); ?></p>
                                                </div>
                                            <?php endif; ?>
                                        </div>

                                        <?php if(!$presentationConfirmation): ?>
                                            <div class="mt-6">
                                                <form action="<?php echo e(route('biro.confirm-presentation')); ?>" method="POST" class="space-y-4">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="announcement_id" value="<?php echo e($announcement->id); ?>">
                                                    <div class="flex space-x-4">
                                                        <button type="submit" name="status" value="confirmed" class="px-4 py-2 text-white bg-green-600 rounded hover:bg-green-700">
                                                            Konfirmasi Kehadiran
                                                        </button>
                                                        <button type="submit" name="status" value="declined" class="px-4 py-2 text-white bg-red-600 rounded hover:bg-red-700">
                                                            Tidak Dapat Hadir
                                                        </button>
                                                    </div>
                                                </form>
                                            </div>
                                        <?php else: ?>
                                            <div class="mt-4 p-4 <?php echo e($presentationConfirmation->status === 'confirmed' ? 'bg-green-100' : 'bg-red-100'); ?> rounded-lg">
                                                <p class="font-semibold">
                                                    Status Konfirmasi:
                                                    <?php echo e($presentationConfirmation->status === 'confirmed' ? 'Akan Hadir' : 'Tidak Dapat Hadir'); ?>

                                                </p>
                                            </div>
                                        <?php endif; ?>
                                <?php else: ?>
                                    <div class="p-6 bg-white border border-gray-200 rounded-lg">
                                        <h3 class="mb-4 text-lg font-semibold text-gray-800">Mohon Maaf</h3>
                                        <div class="mb-6 prose max-w-none">
                                            <p>Mohon maaf proposal Anda belum terpilih untuk melanjutkan ke tahap presentasi.</p>
                                            <p>Kami mengucapkan terima kasih atas partisipasi Anda dalam proses tender ini.</p>
                                        </div>
                                        <div class="mt-4 text-sm text-gray-600">
                                            <p>Tanggal Pengumuman: <?php echo e($announcement->created_at->format('d M Y H:i')); ?></p>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php else: ?>
                            <div class="p-6 bg-white border rounded-lg">
                                <p class="text-gray-600">Belum ada pengumuman saat ini.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /mnt/windows/Project Web/website/codeigniter/web_kkl/Open_tender-laravel/open_tender_lv-1/resources/views/biro/announcements.blade.php ENDPATH**/ ?>