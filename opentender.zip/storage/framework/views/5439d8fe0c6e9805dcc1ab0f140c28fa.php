<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="<?php echo e($class ?? 'w-20 h-20'); ?> fill-current">
    <path d="M12 7V3H2v18h20V7H12zM6 19H4v-2h2v2zm0-4H4v-2h2v2zm0-4H4V9h2v2zm0-4H4V5h2v2zm4 12H8v-2h2v2zm0-4H8v-2h2v2zm0-4H8V9h2v2zm0-4H8V5h2v2zm10 12h-8v-2h2v-2h-2v-2h2v-2h-2V9h8v10zm-2-8h-2v2h2v-2zm0 4h-2v2h2v-2z"/>
</svg>
<?php /**PATH /mnt/windows/Project Web/website/codeigniter/web_kkl/Open_tender-laravel/open_tender_lv-1/resources/views/components/application-logo.blade.php ENDPATH**/ ?>