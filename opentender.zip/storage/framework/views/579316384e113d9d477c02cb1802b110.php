<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="text-xl font-semibold leading-tight text-gray-800">
            Buat Pengumuman Baru
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="mx-auto max-w-7xl sm:px-6 lg:px-8">
            <div class="overflow-hidden bg-white shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <form method="POST" action="<?php echo e(route('admin.announcements.store')); ?>" class="space-y-6">
                        <?php echo csrf_field(); ?>
                        <div>
                            <label for="type" class="block text-sm font-medium text-gray-700">Tipe Pengumuman</label>
                            <select name="type" id="type" required class="block w-full mt-1 border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500">
                                <option value="presentation">Pengumuman Presentasi</option>
                                <option value="winner">Pengumuman Pemenang Tender</option>
                            </select>
                        </div>

                        <div>
                            <label for="title" class="block text-sm font-medium text-gray-700">Judul Pengumuman</label>
                            <input type="text" name="title" id="title" required class="block w-full mt-1 border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500">
                        </div>

                        <div>
                            <label for="content" class="block text-sm font-medium text-gray-700">Isi Pengumuman</label>
                            <textarea name="content" id="content" rows="5" required class="block w-full mt-1 border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"></textarea>
                            <p class="mt-1 text-sm text-gray-500" id="content-help">Masukkan informasi lengkap tentang pengumuman.</p>
                        </div>

                        <div>
                            <label for="announcement_date" class="block text-sm font-medium text-gray-700">Tanggal Pelaksanaan</label>
                            <input type="datetime-local" name="announcement_date" id="announcement_date" required class="block w-full mt-1 border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500">
                        </div>

                        <div id="presentation-biros-section">
                            <label class="block text-sm font-medium text-gray-700 mb-2">Pilih Biro yang Lolos ke Tahap Presentasi</label>
                            <div class="mt-2 p-4 border rounded-md max-h-96 overflow-y-auto">
                                <?php
                                    $reviewedBiros = \App\Models\User::whereHas('proposals', function($query) {
                                        $query->whereIn('status', ['accepted']);
                                    })->get();
                                ?>

                                <?php if($reviewedBiros->isEmpty()): ?>
                                    <p class="text-gray-500">Belum ada biro yang dapat dipilih.</p>
                                <?php else: ?>
                                    <?php $__currentLoopData = $reviewedBiros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $biro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $proposal = $biro->proposals()->latest()->first();
                                        ?>
                                        <div class="flex items-center space-x-3 py-2">
                                            <input type="checkbox"
                                                id="biro_<?php echo e($biro->id); ?>"
                                                name="selected_biros[]"
                                                value="<?php echo e($biro->id); ?>"
                                                class="h-4 w-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500">
                                            <label for="biro_<?php echo e($biro->id); ?>" class="text-sm text-gray-700">
                                                <?php echo e($biro->name); ?> - <?php echo e($proposal->nama_biro); ?>

                                            </label>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                            <p class="mt-1 text-sm text-gray-500">Hanya biro yang proposalnya diterima yang dapat dipilih.</p>
                        </div>

                        <div id="winner-biros-section" style="display: none;">
                            <label class="block text-sm font-medium text-gray-700 mb-2">Pilih Biro Pemenang Tender</label>
                            <div class="mt-2 p-4 border rounded-md max-h-96 overflow-y-auto">
                                <?php
                                    $confirmedBiros = \App\Models\User::whereHas('presentationConfirmations', function($query) {
                                        $query->where('status', 'confirmed');
                                    })->whereHas('proposals', function($query) {
                                        $query->where('status', 'accepted');
                                    })->get();
                                ?>

                                <?php if($confirmedBiros->isEmpty()): ?>
                                    <p class="text-gray-500">Belum ada biro yang mengkonfirmasi kehadiran presentasi.</p>
                                <?php else: ?>
                                    <?php $__currentLoopData = $confirmedBiros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $biro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $proposal = $biro->proposals()->where('status', 'accepted')->latest()->first();
                                        ?>
                                        <?php if($proposal): ?>
                                            <div class="flex items-center space-x-3 py-2">
                                                <input type="radio"
                                                    id="winner_biro_<?php echo e($biro->id); ?>"
                                                    name="selected_biros[]"
                                                    value="<?php echo e($biro->id); ?>"
                                                    class="h-4 w-4 text-blue-600 border-gray-300 rounded-full focus:ring-blue-500">
                                                <label for="winner_biro_<?php echo e($biro->id); ?>" class="text-sm text-gray-700">
                                                    <?php echo e($biro->name); ?> - <?php echo e($proposal->nama_biro); ?>

                                                </label>
                                            </div>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                            <p class="mt-1 text-sm text-gray-500">Hanya biro yang telah mengkonfirmasi kehadiran presentasi dan memiliki proposal yang diterima yang dapat dipilih.</p>
                        </div>

                        <div class="flex justify-end space-x-3">
                            <a href="<?php echo e(route('admin.announcements.index')); ?>" class="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50">
                                Batal
                            </a>
                            <button type="submit" class="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700">
                                Kirim Pengumuman
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const typeSelect = document.getElementById('type');
            const presentationSection = document.getElementById('presentation-biros-section');
            const winnerSection = document.getElementById('winner-biros-section');
            const contentHelp = document.getElementById('content-help');

            typeSelect.addEventListener('change', function() {
                if (this.value === 'presentation') {
                    presentationSection.style.display = 'block';
                    winnerSection.style.display = 'none';
                    contentHelp.textContent = 'Masukkan informasi lengkap tentang jadwal dan tempat presentasi.';
                } else {
                    presentationSection.style.display = 'none';
                    winnerSection.style.display = 'block';
                    contentHelp.textContent = 'Masukkan informasi lengkap tentang pengumuman pemenang tender.';
                }
            });
        });
    </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /mnt/windows/Project Web/website/codeigniter/web_kkl/Open_tender-laravel/open_tender_lv-1/resources/views/admin/announcements/create.blade.php ENDPATH**/ ?>