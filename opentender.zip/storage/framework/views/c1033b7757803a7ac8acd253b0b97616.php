<?php
    use Illuminate\Support\Str;
?>

<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="text-xl font-semibold leading-tight text-gray-800">
            <?php echo e(__('Submit Proposal - Step 2')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="mx-auto max-w-7xl sm:px-6 lg:px-8">
            <div class="overflow-hidden bg-white shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <div class="mb-6">
                        <h3 class="mb-2 text-lg font-semibold">Format Nama File:</h3>
                        <ul class="mt-1 ml-4 text-sm text-gray-600 list-disc">
                            <li>KTP: <?php echo e(Str::slug($proposal->nama_biro)); ?>_ktp.pdf/jpg/png</li>
                            <li>Foto Kantor: <?php echo e(Str::slug($proposal->nama_biro)); ?>_kantor.jpg/png</li>
                            <li>Akta Notaris: <?php echo e(Str::slug($proposal->nama_biro)); ?>_akta.pdf/jpg/png</li>
                            <li>Company Profile: <?php echo e(Str::slug($proposal->nama_biro)); ?>_companyprofile.pdf</li>
                            <li>Penawaran: <?php echo e(Str::slug($proposal->nama_biro)); ?>_penawaran.pdf</li>
                        </ul>
                    </div>

                    <form method="POST" action="<?php echo e(route('proposal.submitStep2')); ?>" enctype="multipart/form-data" class="space-y-6">
                        <?php echo csrf_field(); ?>

                        <div class="grid grid-cols-1 gap-6 md:grid-cols-2">
                            <!-- Scan KTP -->
                            <div class="space-y-2">
                                <label class="block text-sm font-medium text-gray-700">Scan KTP sesuai NPWP</label>
                                <input type="file"
                                    id="scan_ktp"
                                    name="scan_ktp"
                                    data-filepond
                                    accept="application/pdf,image/jpeg,image/png"
                                    required>
                                <?php $__errorArgs = ['scan_ktp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-sm text-red-600"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Foto Kantor -->
                            <div class="space-y-2">
                                <label class="block text-sm font-medium text-gray-700">Foto Kantor</label>
                                <input type="file"
                                    id="foto_kantor"
                                    name="foto_kantor"
                                    data-filepond
                                    accept="image/jpeg,image/png"
                                    required>
                                <?php $__errorArgs = ['foto_kantor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-sm text-red-600"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Scan Akta -->
                            <div class="space-y-2">
                                <label class="block text-sm font-medium text-gray-700">Scan Akta Notaris</label>
                                <input type="file"
                                    id="scan_akta"
                                    name="scan_akta"
                                    data-filepond
                                    accept="application/pdf,image/jpeg,image/png"
                                    required>
                                <?php $__errorArgs = ['scan_akta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-sm text-red-600"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Company Profile -->
                            <div class="space-y-2">
                                <label class="block text-sm font-medium text-gray-700">Company Profile</label>
                                <input type="file"
                                    id="company_profile"
                                    name="company_profile"
                                    data-filepond
                                    accept="application/pdf"
                                    required>
                                <?php $__errorArgs = ['company_profile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-sm text-red-600"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Penawaran -->
                            <div class="space-y-2 md:col-span-2">
                                <label class="block text-sm font-medium text-gray-700">Dokumen Penawaran</label>
                                <input type="file"
                                    id="penawaran"
                                    name="penawaran"
                                    data-filepond
                                    accept="application/pdf"
                                    required>
                                <?php $__errorArgs = ['penawaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-sm text-red-600"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="mt-6">
                            <div class="flex items-start">
                                <div class="flex items-center h-5">
                                    <input id="agree_terms" name="agree_terms" type="checkbox" required
                                        class="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500">
                                </div>
                                <div class="ml-3 text-sm">
                                    <label for="agree_terms" class="font-medium text-gray-700">Saya menyetujui syarat dan ketentuan yang berlaku</label>
                                </div>
                            </div>
                            <?php $__errorArgs = ['agree_terms'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="flex justify-end space-x-4">
                            <a href="<?php echo e(route('proposal.step1')); ?>" class="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                                Kembali
                            </a>
                            <button type="submit" id="submitButton" class="inline-flex items-center px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-md shadow-sm hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                                Submit Proposal
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->startPush('styles'); ?>
    <link href="https://unpkg.com/filepond/dist/filepond.css" rel="stylesheet">
    <link href="https://unpkg.com/filepond-plugin-image-preview/dist/filepond-plugin-image-preview.css" rel="stylesheet">
    <?php $__env->stopPush(); ?>

    <?php $__env->startPush('scripts'); ?>
    <script src="https://unpkg.com/filepond-plugin-image-preview/dist/filepond-plugin-image-preview.js"></script>
    <script src="https://unpkg.com/filepond-plugin-file-validate-type/dist/filepond-plugin-file-validate-type.js"></script>
    <script src="https://unpkg.com/filepond-plugin-file-validate-size/dist/filepond-plugin-file-validate-size.js"></script>
    <script src="https://unpkg.com/filepond/dist/filepond.js"></script>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Register FilePond plugins
            FilePond.registerPlugin(
                FilePondPluginImagePreview,
                FilePondPluginFileValidateType,
                FilePondPluginFileValidateSize
            );

            // Initialize FilePond for each file input
            const inputs = {
                'scan_ktp': ['application/pdf', 'image/jpeg', 'image/png'],
                'foto_kantor': ['image/jpeg', 'image/png'],
                'scan_akta': ['application/pdf', 'image/jpeg', 'image/png'],
                'company_profile': ['application/pdf'],
                'penawaran': ['application/pdf']
            };

            Object.entries(inputs).forEach(([inputId, acceptedFileTypes]) => {
                const element = document.getElementById(inputId);
                if (element) {
                    const pond = FilePond.create(element, {
                        acceptedFileTypes: acceptedFileTypes,
                        storeAsFile: true,
                        maxFileSize: '2MB',
                        labelIdle: 'Drag & Drop atau <span class="filepond--label-action">Browse</span>',
                        labelFileProcessingComplete: 'File siap diupload',
                        labelFileProcessingError: 'Error saat memproses file',
                        labelFileProcessingAborted: 'Upload dibatalkan',
                        labelMaxFileSizeExceeded: 'File terlalu besar',
                        labelMaxFileSize: 'Maksimal ukuran file adalah 2MB',
                        required: true
                    });
                }
            });

            // Handle form submission
            const form = document.querySelector('form');
            const submitButton = document.getElementById('submitButton');
            const agreeTerms = document.getElementById('agree_terms');

            if (agreeTerms && submitButton) {
                agreeTerms.addEventListener('change', () => {
                    submitButton.disabled = !agreeTerms.checked;
                });

                submitButton.disabled = !agreeTerms.checked;
            }
        });
    </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /mnt/windows/Project Web/website/codeigniter/web_kkl/Open_tender-laravel/open_tender_lv-1/resources/views/proposal/step2.blade.php ENDPATH**/ ?>